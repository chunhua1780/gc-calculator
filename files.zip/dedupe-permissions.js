#!/usr/bin/env node
// Cordova hook: 自动去除AndroidManifest.xml中重复的<uses-permission>
const fs = require('fs');
const path = require('path');

module.exports = function(context) {
    const manifestPath = path.join(
        context.opts.projectRoot,
        'platforms/android/app/src/main/AndroidManifest.xml'
    );

    if (!fs.existsSync(manifestPath)) {
        console.log('[dedupe-permissions] manifest not found, skipping');
        return;
    }

    let content = fs.readFileSync(manifestPath, 'utf8');

    // 提取所有 uses-permission 行
    const permRegex = /<uses-permission[^>]*android:name="([^"]+)"[^>]*\/>/g;
    const seen = new Set();
    const lines = [];
    let match;
    let lastIndex = 0;
    let result = '';

    while ((match = permRegex.exec(content)) !== null) {
        const permName = match[1];
        const fullMatch = match[0];
        result += content.slice(lastIndex, match.index);
        if (!seen.has(permName)) {
            seen.add(permName);
            result += fullMatch;
        } else {
            console.log('[dedupe-permissions] removing duplicate: ' + permName);
        }
        lastIndex = match.index + fullMatch.length;
    }
    result += content.slice(lastIndex);

    fs.writeFileSync(manifestPath, result, 'utf8');
    console.log('[dedupe-permissions] done, ' + seen.size + ' unique permissions kept');
};
